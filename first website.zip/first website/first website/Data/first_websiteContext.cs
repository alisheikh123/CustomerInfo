﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using first_website.Models;

namespace first_website.Data
{
    public class first_websiteContext : DbContext
    {
        public first_websiteContext (DbContextOptions<first_websiteContext> options)
            : base(options)
        {
        }

        public DbSet<first_website.Models.Customer>? Customer { get; set; }
    }
}
